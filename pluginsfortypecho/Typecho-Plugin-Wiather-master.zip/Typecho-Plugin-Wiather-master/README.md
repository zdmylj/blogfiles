# Typecho-Plugin-Wiather
Wiather - A Weather Plugin for Typecho

## 插件信息

插件名称：`Wiather`

作者：Wibus

作者博客：https://blog.iucky.cn

参照项目：AliceStyle


## 插件特点

![自带检测更新机制](https://gitee.com/wibus/blog-assets-goo/raw/master/asset-pic/plugin-setting-1.jpg)
![多种自定义设置](https://gitee.com/wibus/blog-assets-goo/raw/master/asset-pic/plugin-setting-2.jpg)

## 弹窗样式

![原生alert弹窗](https://gitee.com/wibus/blog-assets-goo/raw/master/asset-pic/2020-12-5-alert.jpg)
![handsome自带弹窗](https://gitee.com/wibus/blog-assets-goo/raw/master/asset-pic/2020-12-5-handsome-alert.jpg)
![Sweetalert2](https://gitee.com/wibus/blog-assets-goo/raw/master/asset-pic/2020-12-5-sweet-alert.jpg)