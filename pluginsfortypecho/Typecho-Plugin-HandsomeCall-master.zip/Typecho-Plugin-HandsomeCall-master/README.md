# Typecho-Plugin-HandsomeCall

一款专属于Handsome的信息提示插件

目前版本：`V1.0`

作者：`Wibus`

参考插件：WeiFeng `HandsomeNotice`



## 食用教程

```bash
git clone https://github.com/wibus-wee/Typecho-Plugin-HandsomeCall.git
```

1. 先下载插件放入/usr/plugins/下，改名为HandsomeCall

2. 在后台管理插件中点按开启插件即可使用



| 插件版本         | 更新内容               |
| ---------------- | ---------------------- |
| V1.0             | 最初的版本             |
| V1.1（准备发布） | 将输出语言变得更加好听 |
| V2.0（预划）     | 新增复制等操作提醒     |

## 插件将会输出的文字

标题：Hello！<strong>"来访域名"</strong>的朋友！你好哇

**使用Cookie判断**

FirstView：欢迎来到小站里喝茶~  我倍感荣幸啊 嘿嘿

Else：您直接访问了本站!  莫非您记住了我的<strong>域名</strong>.厉害~

**通过搜索引擎访问的的**

您通过 <strong>百度</strong> 找到了我，厉害！

您居然通过 <strong>Google</strong> 找到了我! 一定是个技术宅吧!

……还有一些



感谢你通过 <strong>Google</strong> 订阅我!  既然过来读原文了. 欢迎留言指导啊.嘿嘿 ^_^

感谢你通过 <strong>鲜果</strong> 订阅我!  既然过来读原文了. 欢迎留言指导啊.嘿嘿 ^_^

……还有一些

不想从插件复制黏贴了，立马下载使用吧～