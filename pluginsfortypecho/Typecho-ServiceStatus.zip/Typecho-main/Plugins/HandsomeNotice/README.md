# HandsomeNotice
Handsome专用消息提示插件

## 食用教程
先下载插件放入/usr/plugins/下，改名为HandsomeNotice  
然后在插件管理开启插件即可