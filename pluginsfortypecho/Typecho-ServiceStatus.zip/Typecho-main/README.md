# Typecho
Typecho的一些插件和模板

## 服务器状态
文件：/Themes/handsome/status.php  
版本：1.0.5  
更新：新增了加载和错误提示  
用途：为博客添加一个服务器状态页  
详情：https://wfblog.net/archives/blog_status.html  
  
## notice
文件：/Plugins/notice  
版本：1.0.0  
更新：由原来的样式改为了toastr  
用途：进入博客阅读文章等等右上角提示  
详情：https://wfblog.net/  

## ServerStatus
文件：/Plugins/ServerStatus  
版本：2.0.0  
更新：重大更新，详见博客  
用途：为博客添加一个服务器状态页  
详情：https://wfblog.net/archives/serverstatus_plugin.html  

## HandsomeNotice
文件：/Plugins/HandsomeNotice  
版本：1.0.0  
更新：修改为handsome自带的弹窗  
用途：专属于Handsome主题的消息提示插件  
详情：https://wfblog.net/  
